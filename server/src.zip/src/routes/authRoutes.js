/**
 * authRoutes.js — Auth API Routes
 *
 * Route → Middleware chain → Controller mapping.
 *
 * Pattern: [validators] → validate → protect? → controller
 *
 * POST /register          — public
 * POST /login             — public
 * POST /logout            — private
 * GET  /me                — private
 * POST /refresh-token     — public (uses refresh cookie)
 * POST /forgot-password   — public
 * POST /reset-password/:token — public
 * GET  /verify-email/:token   — public
 * POST /resend-verification   — public
 */

const express = require('express');
const router = express.Router();

const authController = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const validate = require('../middleware/validate');
const {
  registerValidator,
  loginValidator,
  forgotPasswordValidator,
  resetPasswordValidator,
  resendVerificationValidator,
} = require('../validators/authValidators');

// ─── Public Routes ────────────────────────────────────────────────────────────

router.post('/register', registerValidator, validate, authController.register);
router.post('/login', loginValidator, validate, authController.login);
router.get('/verify-email/:token', authController.verifyEmail);
router.post('/resend-verification', resendVerificationValidator, validate, authController.resendVerification);
router.post('/forgot-password', forgotPasswordValidator, validate, authController.forgotPassword);
router.post('/reset-password/:token', resetPasswordValidator, validate, authController.resetPassword);
router.post('/refresh-token', authController.refreshToken);

// ─── Private Routes ───────────────────────────────────────────────────────────

router.post('/logout', protect, authController.logout);
router.get('/me', protect, authController.getMe);

module.exports = router;
