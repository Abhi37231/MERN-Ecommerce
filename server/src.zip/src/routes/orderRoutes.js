/**
 * orderRoutes.js — Order API Routes
 *
 * POST   /api/v1/orders               — createOrder (private)
 * GET    /api/v1/orders/my-orders     — getMyOrders (private)
 * GET    /api/v1/orders/:id           — getOrderById (private)
 * GET    /api/v1/orders               — getAllOrders (admin)
 * PATCH  /api/v1/orders/:id/status    — updateOrderStatus (admin)
 * PATCH  /api/v1/orders/:id/payment   — updatePaymentStatus (admin)
 */

const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { protect, authorize } = require('../middleware/auth');

// Apply protect middleware to all routes below
router.use(protect);

router.post('/', orderController.createOrder);
router.get('/my-orders', orderController.getMyOrders);
router.get('/:id', orderController.getOrderById);

// Admin only routes
router.use(authorize('admin'));
router.get('/', orderController.getAllOrders);
router.patch('/:id/status', orderController.updateOrderStatus);
router.patch('/:id/payment', orderController.updatePaymentStatus);

module.exports = router;
