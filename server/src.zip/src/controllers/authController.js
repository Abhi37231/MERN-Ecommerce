const User = require("../models/User");
const Cart = require("../models/Cart");
const Wishlist = require("../models/Wishlist");

const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");

const { sendSuccess } = require("../utils/apiResponse");

const {
  generateAccessToken,
  generateRefreshToken,
  setTokenCookies,
} = require("../utils/jwtUtils");

const {
  generateToken,
} = require("../utils/generateToken");

const {
  sendEmail,
  emailVerificationTemplate,
} = require("../utils/sendEmail");

const sendAuthResponse = (res, statusCode, message, user) => {
  const accessToken = generateAccessToken(user._id, user.role);
  const refreshToken = generateRefreshToken(user._id);

  setTokenCookies(res, accessToken, refreshToken);

  return sendSuccess(res, statusCode, message, {
    user,
    accessToken,
    refreshToken,
  });
};

const register = asyncHandler(async (req, res, next) => {
  const { firstName, lastName, email, password, phone } = req.body;

  const existingUser = await User.findOne({ email });

  if (existingUser) {
    return next(
      new AppError("An account with this email already exists.", 409)
    );
  }

  const { rawToken, hashedToken, expiresAt } = generateToken(24 * 60);

  const user = await User.create({
    firstName,
    lastName,
    email,
    password,
    phone,
    emailVerificationToken: hashedToken,
    emailVerificationExpires: expiresAt,
  });

  await Promise.all([
    Cart.create({
      user: user._id,
      items: [],
    }),
    Wishlist.create({
      user: user._id,
      products: [],
    }),
  ]);

  const verificationUrl = `${process.env.CLIENT_URL}/verify-email/${rawToken}`;

  try {
    await sendEmail({
      to: user.email,
      subject: "Verify your ShopSphere email",
      html: emailVerificationTemplate(
        user.firstName,
        verificationUrl
      ),
    });
  } catch (err) {
    console.error(err.message);
  }

  return sendAuthResponse(
    res,
    201,
    "Account created successfully! Please verify your email.",
    user
  );
});

module.exports = {
  register,
};