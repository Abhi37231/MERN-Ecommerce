/**
 * orderController.js — Order Controller
 *
 * POST   /api/v1/orders               — createOrder (private, COD)
 * GET    /api/v1/orders/my-orders     — getMyOrders (private)
 * GET    /api/v1/orders/:id           — getOrderById (private)
 * GET    /api/v1/orders               — getAllOrders (admin)
 * PATCH  /api/v1/orders/:id/status    — updateOrderStatus (admin)
 * PATCH  /api/v1/orders/:id/payment   — updatePaymentStatus (admin)
 *
 * Note: Razorpay payment orders are handled in paymentController.
 *       This controller handles standard Cash on Delivery (COD) orders.
 */

const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const asyncHandler = require('../utils/asyncHandler');
const AppError = require('../utils/AppError');
const { sendSuccess, paginate } = require('../utils/apiResponse');
const { sendEmail, orderConfirmationTemplate } = require('../utils/sendEmail');

/**
 * @desc    Create new order (COD)
 * @route   POST /api/v1/orders
 * @access  Private
 */
const createOrder = asyncHandler(async (req, res, next) => {
  const { shippingAddress, paymentMethod, customerNote } = req.body;

  if (!shippingAddress) {
    return next(new AppError('Shipping address is required.', 400));
  }

  // 1. Get user cart
  const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');

  if (!cart || cart.items.length === 0) {
    return next(new AppError('Your cart is empty.', 400));
  }

  // 2. Validate stock for all items
  for (const item of cart.items) {
    if (!item.product) {
       return next(new AppError('A product in your cart no longer exists.', 400));
    }
    if (item.product.stock < item.quantity) {
      return next(new AppError(`Insufficient stock for ${item.name}.`, 400));
    }
  }

  // 3. Calculate Totals
  const subtotal = cart.subtotal;
  const couponDiscount = cart.couponDiscount || 0;
  const shippingCost = subtotal > 1000 ? 0 : 50; // Free shipping over 1000
  const taxAmount = 0; // Assuming tax is included in price for now
  const totalAmount = subtotal - couponDiscount + shippingCost + taxAmount;

  // 4. Create Order Items from Cart Snapshot
  const orderItems = cart.items.map(item => ({
    product: item.product._id,
    name: item.name,
    image: item.image,
    price: item.price,
    discountedPrice: item.discountedPrice,
    quantity: item.quantity,
    variant: item.variant,
    sku: item.product.sku,
  }));

  // 5. Build Order Document
  const order = await Order.create({
    user: req.user._id,
    items: orderItems,
    shippingAddress,
    subtotal,
    shippingCost,
    couponDiscount,
    couponCode: cart.couponCode,
    taxAmount,
    totalAmount,
    payment: {
      method: paymentMethod || 'cod',
      status: paymentMethod === 'cod' ? 'pending' : 'pending',
    },
    customerNote,
    status: 'pending',
  });

  // 6. Update Product Stock and Sold Count
  for (const item of cart.items) {
    await Product.findByIdAndUpdate(item.product._id, {
      $inc: { stock: -item.quantity, soldCount: item.quantity }
    });
  }

  // 7. Clear Cart
  await Cart.findOneAndUpdate(
    { user: req.user._id },
    { items: [], coupon: null, couponCode: null, couponDiscount: 0 }
  );

  // 8. Send Confirmation Email (Async)
  try {
    await sendEmail({
      to: req.user.email,
      subject: `Order Confirmation - ${order.orderNumber}`,
      html: orderConfirmationTemplate(req.user.firstName, order.orderNumber, order.totalAmount)
    });
  } catch (error) {
    console.error('Order confirmation email failed:', error);
  }

  sendSuccess(res, 201, 'Order placed successfully.', { order });
});

/**
 * @desc    Get logged in user orders
 * @route   GET /api/v1/orders/my-orders
 * @access  Private
 */
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
  sendSuccess(res, 200, 'Orders retrieved.', { orders });
});

/**
 * @desc    Get order by ID
 * @route   GET /api/v1/orders/:id
 * @access  Private
 */
const getOrderById = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id).populate('user', 'firstName lastName email');

  if (!order) {
    return next(new AppError('Order not found.', 404));
  }

  // Ensure user is authorized to view this order
  if (order.user._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    return next(new AppError('Not authorized to view this order.', 403));
  }

  sendSuccess(res, 200, 'Order retrieved.', { order });
});

/**
 * @desc    Get all orders (Admin)
 * @route   GET /api/v1/orders
 * @access  Admin
 */
const getAllOrders = asyncHandler(async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, parseInt(req.query.limit) || 20);
  const skip = (page - 1) * limit;

  const filter = {};
  if (req.query.status) filter.status = req.query.status;

  const [orders, total] = await Promise.all([
    Order.find(filter).populate('user', 'firstName lastName email').sort({ createdAt: -1 }).skip(skip).limit(limit),
    Order.countDocuments(filter)
  ]);

  sendSuccess(res, 200, 'Orders retrieved.', { orders }, paginate(page, limit, total));
});

/**
 * @desc    Update order status
 * @route   PATCH /api/v1/orders/:id/status
 * @access  Admin
 */
const updateOrderStatus = asyncHandler(async (req, res, next) => {
  const { status, comment, trackingNumber, trackingUrl, shippingProvider } = req.body;

  const order = await Order.findById(req.params.id);

  if (!order) {
    return next(new AppError('Order not found.', 404));
  }

  if (order.status === 'delivered') {
    return next(new AppError('Cannot update status of a delivered order.', 400));
  }
  
  if (order.status === 'cancelled') {
      return next(new AppError('Cannot update status of a cancelled order.', 400));
  }

  // Valid state transitions could be enforced here

  order.status = status;
  
  // Track shipping info if provided
  if (trackingNumber) order.trackingNumber = trackingNumber;
  if (trackingUrl) order.trackingUrl = trackingUrl;
  if (shippingProvider) order.shippingProvider = shippingProvider;
  
  if (status === 'delivered') order.deliveredAt = Date.now();
  if (status === 'cancelled') {
      order.cancelledAt = Date.now();
      order.cancellationReason = comment;
      
      // Refund stock
      for(const item of order.items) {
          await Product.findByIdAndUpdate(item.product, {
              $inc: { stock: item.quantity, soldCount: -item.quantity }
          });
      }
  }

  order.statusHistory.push({
    status,
    comment,
    updatedBy: req.user._id,
    updatedAt: Date.now()
  });

  await order.save();

  sendSuccess(res, 200, 'Order status updated.', { order });
});

/**
 * @desc    Update payment status
 * @route   PATCH /api/v1/orders/:id/payment
 * @access  Admin
 */
const updatePaymentStatus = asyncHandler(async (req, res, next) => {
    const { status, transactionId } = req.body;
    
    const order = await Order.findById(req.params.id);
    if(!order) return next(new AppError('Order not found', 404));
    
    order.payment.status = status;
    if(transactionId) order.payment.transactionId = transactionId;
    if(status === 'paid') order.payment.paidAt = Date.now();
    
    await order.save();
    
    sendSuccess(res, 200, 'Payment status updated', { order });
});

module.exports = {
  createOrder,
  getMyOrders,
  getOrderById,
  getAllOrders,
  updateOrderStatus,
  updatePaymentStatus
};
