/**
 * asyncHandler — Higher-order function that wraps async route handlers.
 *
 * Why: Express doesn't automatically catch errors thrown inside async functions.
 *      Without this, an unhandled promise rejection would crash the server.
 *
 * Pattern: Wraps any async fn(req, res, next) → if the promise rejects,
 *          the error is forwarded to Express's global error handler via next(err).
 *
 * Usage:
 *   router.get('/route', asyncHandler(async (req, res) => { ... }));
 */
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = asyncHandler;
